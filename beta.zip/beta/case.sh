waktu=`date +%S`

##waktu="a"
case $waktu in
  "01")
    source acak-soal/1
    ;;
  "02")
    source acak-soal/2
    ;;
  "03")
    source acak-soal/3
    ;;
  "04")
    source acak-soal/4
    ;;
  "05")
    source acak-soal/5
    ;;
  "06")
    source acak-soal/6
    ;;
  "07")
    source acak-soal/7
    ;;
  "08")
    source acak-soal/8
    ;;
  "09")
    source acak-soal/9
    ;;
  "10")
    source acak-soal/10
    ;;
  "11")
    source acak-soal/11
    ;;
  "12")
    source acak-soal/12
    ;;
  "13")
    source acak-soal/13
    ;;
  "14")
    source acak-soal/14
    ;;
  "15")
    source acak-soal/15
    ;;
  "16")
    source acak-soal/16
    ;;
  "17")
    source acak-soal/17
    ;;
  "18")
    source acak-soal/18
    ;;
  "19")
    source acak-soal/19
    ;;
  "20")
    source acak-soal/20
    ;;
  "21")
    source acak-soal/21
    ;;
  "22")
    source acak-soal/22
    ;;
  "23")
    source acak-soal/23
    ;;
  "24")
    source acak-soal/24
    ;;
  "25")
    source acak-soal/25
    ;;
  "26")
    source acak-soal/26
    ;;
  "27")
    source acak-soal/27
    ;;
  "28")
    source acak-soal/28
    ;;
  "29")
    source acak-soal/29
    ;;
  "30")
    source acak-soal/30
    ;;
  "31")
    source acak-soal/31
    ;;
  "32")
    source acak-soal/32
    ;;
  "33")
    source acak-soal/33
    ;;
  "34")
    source acak-soal/34
    ;;
  "35")
    source acak-soal/35
    ;;
  "36")
    source acak-soal/36
    ;;
  "37")
    source acak-soal/37
    ;;
  "38")
    source acak-soal/38
    ;;
  "39")
    source acak-soal/39
    ;;
  "40")
    source acak-soal/40
    ;;
  "41")
    source acak-soal/41
    ;;
  "42")
    source acak-soal/42
    ;;
  "43")
    source acak-soal/43
    ;;
  "44")
    source acak-soal/44
    ;;
  "45")
    source acak-soal/45
    ;;
  "46")
    source acak-soal/46
    ;;
  "47")
    source acak-soal/47
    ;;
  "48")
    source acak-soal/48
    ;;
  "49")
    source acak-soal/49
    ;;
  "50")
    source acak-soal/50
    ;;
  "51")
    source acak-soal/51
    ;;
  "52")
    source acak-soal/52
    ;;
  "53")
    source acak-soal/53
    ;;
  "54")
    source acak-soal/54
    ;;
  "55")
    source acak-soal/55
    ;;
  "56")
    source acak-soal/56
    ;;
  "57")
    source acak-soal/57
    ;;
  "58")
    source acak-soal/58
    ;;
  "59")
    source acak-soal/59
    ;;
  "60")
    source acak-soal/60
    ;;
    *)
      echo "\033[1;31m   Maaf jawaban anda salah\033[0m"
      ;;
  esac
