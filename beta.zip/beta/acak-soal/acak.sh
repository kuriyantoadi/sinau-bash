acak=`shuf -e soal1 soal2 soal3 soal4 soal5 soal6 soal7 soal8 soal9 soal10 soal11 soal12 soal13 soal14 soal15 soal16 soal17 soal18 soal19 soal20 soal21 soal22 soal23 soal24 soal25 soal26 soal27 soal28 soal29 soal30 soal31 soal32 soal33 soal34 soal35 soal36 soal37 soal38 soal39 soal40 soal41 soal42 soal43 soal44 soal45 soal46 soal47 soal48 soal49 soal50`
echo -n $acak
